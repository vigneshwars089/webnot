'use strict';

var commons = require('js-project-commons');

module.exports = commons.lint.eslint.web;
