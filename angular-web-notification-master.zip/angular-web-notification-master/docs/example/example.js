/*global console: false */
/*jslint unparam: true*/
var period;
$.get('http://10.219.47.40:4000/usersettings', {}, function(data){
  period=Object.keys(data).length;
});
  setInterval(retrieveItems, 5000);
 function retrieveItems(){
$.get('http://10.219.47.40:4000/usersettings', {}, function(data){
		console.log(data);
    console.log(Object.keys(data).length);
    if(Object.keys(data).length!=period){
    onClick();
    period=Object.keys(data).length;
  }
      });
    }
    function onClick() {
      webNotification.showNotification("scope.notificationTitle", {
        body: "scope.notificationText",
        icon: 'example/download.png',
        tag:'tag1',
        requireInteraction:true,
        onClick: function onNotificationClicked() {
          console.log(this);
        },
        autoClose: 4000 //auto close the notification after 4 seconds (you can manually close it via hide function)
      }, function onShow(error, hide) {
        if (error) {
          window.alert('Unable to show notification: ' + error.message);
        } else {
          console.log('Notification Shown.');

          setTimeout(function hideNotification() {
            console.log('Hiding notification....');
            hide(); //manually close the notification (you can skip this if you use the autoClose option)
          }, 5000);
        }
      });
    }




    // window.angular.module('exampleApp', [
    //   'angular-web-notification'
    // ]).controller('exampleForm', ['$scope', function ($scope) {
    //   'use strict';
    //
    //   $scope.title = 'Type the subject';
    //   $scope.text = 'Type the Notification message';
    // }]).directive('showButton', ['webNotification', function (webNotification) {
    //   'use strict';
    //
    //   return {
    //     restrict: 'C',
    //     scope: {
    //       notificationTitle: '=',
    //       notificationText: '='
    //     },
    //     link: function (scope, element) {
    //       element.on('click', );
    //     }
    //   };
    // }]);
  // });
