| Date        | Version | Description |
| ----------- | ------- | ----------- |
| 2017-06-26  | v1.2.23 | Maintenance |
| 2017-01-22  | v1.2.0  | Split the internal web notification API into a new project: simple-web-notification |
| 2017-01-13  | v1.0.26 | Maintenance |
| 2016-11-23  | v1.0.19 | Use forked version of html5-desktop-notifications in order to resolve few issues |
| 2016-11-19  | v1.0.18 | Maintenance |
| 2016-11-04  | v1.0.16 | Upgrading to html5-desktop-notifications 3.0.0 |
| 2016-10-16  | v1.0.15 | Maintenance |
| 2016-09-10  | v1.0.6  | Default to website favicon.ico if icon not provided in options |
| 2016-09-07  | v1.0.4  | Callback is now optional |
| 2016-09-07  | v1.0.3  | Maintenance |
| 2016-06-14  | v0.0.78 | Published via NPM (in addition to bower) |
| 2016-06-14  | v0.0.77 | Maintenance |
| 2016-03-08  | v0.0.65 | Added webNotification.permissionGranted attribute |
| 2016-02-24  | v0.0.64 | Maintenance |
| 2015-09-26  | v0.0.31 | Update bower dependencies |
| 2015-09-26  | v0.0.30 | Added 'onClick' option to enable adding onclick event handler for the notification |
| 2015-09-02  | v0.0.29 | Maintenance |
| 2015-08-16  | v0.0.22 | uglify fix |
| 2015-08-02  | v0.0.21 | Maintenance |
| 2015-02-16  | v0.0.7  | Automatic unit tests via karma |
| 2015-02-05  | v0.0.5  | Doc changes |
| 2014-12-30  | v0.0.4  | Doc changes |
| 2014-12-09  | v0.0.3  | API now enables/disables the capability to automatically request for permissions needed to display the notification. |
| 2014-12-08  | v0.0.2  | Initial release |
