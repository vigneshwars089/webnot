var express = require('express');
var app = express();
var sql = require("mssql");
var bodyParser = require('body-parser');

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
  app.get('/data', function (req, res) {
    sql.close();
    var config = {
        user: 'sa',
        password: '12CSR119@MPN',
        server: 'localhost',
        database: 'Automation Kiosk'
    };
    sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();
        request.query('select * from Event', function (err, recordset) {
            if (err) console.log(err)
            for (var i = 0; i < recordset.recordset.length; i++) {
              console.log(recordset.recordset[i].UploadedOn);
            }
            res.send(recordset.recordset);
        });
    });
});

app.get('/usersettings', function (req, res) {
  sql.close();
  var config = {
      user: 'sa',
      password: '12CSR119@MPN',
      server: 'localhost',
      database: 'Automation Kiosk'
  };
  sql.connect(config, function (err) {
      if (err) console.log(err);
      var request = new sql.Request();
      request.query('select * from UserSettings', function (err, recordset) {
          if (err) console.log(err)
          for (var i = 0; i < recordset.recordset.length; i++) {
            console.log(recordset.recordset);
          }
          res.send(recordset.recordset);
      });
  });
});

app.get('/client', function (req, res) {
  sql.close();
  var config = {
      user: 'sa',
      password: '12CSR119@MPN',
      server: 'localhost',
      database: 'Automation Kiosk'
  };
  sql.connect(config, function (err) {
      if (err) console.log(err);
      var request = new sql.Request();
      request.query('select * from ClientPartners', function (err, recordset) {
          if (err) console.log(err)
          for (var i = 0; i < recordset.recordset.length; i++) {
            console.log(recordset.recordset[i].ClientPartnerName);
          }
          res.send(recordset.recordset);
      });
  });
});

app.get('/feedback', function (req, res) {
  sql.close();
  var config = {
      user: 'sa',
      password: '12CSR119@MPN',
      server: 'localhost',
      database: 'Automation Kiosk'
  };
  sql.connect(config, function (err) {
      if (err) console.log(err);
      var request = new sql.Request();
      request.query('select * from FeedbackSurveyQueries', function (err, recordset) {
          if (err) console.log(err)
          for (var i = 0; i < recordset.recordset.length; i++) {
            console.log(recordset.recordset[i].FeedbackQuestionnarieDescription);
          }
          res.send(recordset.recordset);
      });
  });
});

app.post('/chart', function (req, res) {
  console.log(req.body);
  var data = req.body;
  sql.close();
  var config = {
      user: 'sa',
      password: '12CSR119@MPN',
      server: 'localhost',
      database: 'Automation Kiosk'
  };
  sql.connect(config, function (err) {
      if (err) console.log(err);
      var request = new sql.Request();
      var query="insert into cwd_user_log (UserId,CrowdDateLastUpdate,TableAttributeId,AttributeValue,Reason,Comments) values ("+data.name+",'"+data.currenttime+"',"+data.attributeId+","+data.count+",'"+data.reason+"','"+data.message+"')";
      request.query(query , function (err, recordset) {
          if (err) console.log(err)
          res.send("success!!");
      });
  });
});

var server = app.listen(4000, function () {
console.log('Server is running.. on Port 4000');
});
